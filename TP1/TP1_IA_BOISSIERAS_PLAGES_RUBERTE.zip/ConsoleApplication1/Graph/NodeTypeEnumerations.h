#ifndef NODE_TYPE_ENUMS
#define NODE_TYPE_ENUMS
//-----------------------------------------------------------------------------
//  Desc:   enumerates some dummy node values that can be assigned to graph
//          edges and nodes
//-----------------------------------------------------------------------------
  enum 
  {
    invalid_node_index    = -1
  };
  

#endif